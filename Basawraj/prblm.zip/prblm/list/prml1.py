# sum of all the digite of list
def sum(item):
      sum_items=0
      for x in item:
        sum_items += x
      return sum_items
print(sum([20,30,40,40]))