#Write a Python program to get the smallest number from a list
'''def smallest_num(item):
    small_no=item[0]
    for x in item:
       if x<small_no:
         small_no=x
    return small_no
print(smallest_num([20,30,2]))
'''
list=[1,2,4,5]
z=min(list)
print(z)

