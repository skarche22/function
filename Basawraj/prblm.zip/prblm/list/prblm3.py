# Write a Python program to get the largest number from a list.
list=[20,30,40,50]
z=max(list)
print(z)
#this is also soln
'''def max_num_in_list( list ):
    max = list[ 0 ]
    for a in list:
        if a > max:
            max = a
    return max
print(max_num_in_list([1, 2, -8, 0]))'''