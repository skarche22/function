def check(item):
    n=len(item)
    if n==0:
        print("list is empty")
    else:
        print("list is not empty")
check(())
