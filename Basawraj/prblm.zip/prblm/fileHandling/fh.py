# file object variables and methods
# f = open('fh.txt','w')
# print(f.name)
# print(f.mode)
# print(f.readable())
# print(f.writable())
# f.close()
# print(f.closed)


# isfile() method
# from os import path
# #print(os.path.isfile("f_handling.txt"))
# print(path.isfile("f_handling.txt"))

import os
# if os.path.isfile("D:/practice_session_topics/f_handling.txt"):
#     f1 = open("D:/practice_session_topics/f_handling.txt")
#     print("file opened")
#     f1.close()
# else:
#     print("file not found")

# writing data to the file
# f = open('fh.txt','w+')
# f.write("hello ")
# f.write("python ")
# f.seek(0)
# data = f.read()
# print(data)
# f.close()

# f = open("D:/practice_session_topics/f_handling.txt","a")
# print(os.path.isfile("D:/practice_session_topics/f_handling.txt"))
# lis = ["shubham\n","sushant\n","prasad\n","swapnil\n","swastik\n","akshay\n","himanshu\n"]
# t1 = ("a\n","b\n","c\n","d\n","e\n")
# s1 = {"a\n","b\n","c\n","d\n","e\n"}
# f.writelines(lis)
# f.writelines(t1)
# f.writelines(s1)
# f.close()
# print("success")

## reading the data in file
## read()
# f = open("D:/practice_session_topics/f_handling.txt","r")
# data1 = f.read(2)
# data2 = f.read(2)
# print(data1)
# print(data2)
# f.close()
# print("completed")

##readline() & readlines()
# f = open("D:/practice_session_topics/f_handling.txt","r")
# data1 = f.readline()
# data2 = f.readlines()
# print(data1)
# print(data2)
# for i in data2:
#     print(i,end="")
# print(f.readline())
# f.close()

## methods
#tell()
# f = open("D:/practice_session_topics/f_handling.txt","r")
# print(f.tell())
# print(f.read(5))
# print(f.tell())
# f.close()

#seek(position)
# f = open("D:/practice_session_topics/f_handling.txt","r")
# print(f.tell())
# print(f.seek(7))
# print(f.read())
# print(f.seek(2))
# print(f.read(7))

## r+ mode
# read then write
# f = open("D:/practice_session_topics/f_handling.txt","r+")
# print(f.tell())
# data = f.read()
# print(f.tell())
# f.write("hello")
# print(f.tell())
# print(data)
# print(f.tell())
# f.close()

## w+ mode
# writing and then reading
# f = open("D:/practice_session_topics/f_handling.txt","w+")
# print(f.tell())
# f.write("hello")
# print(f.tell())
# print(f.seek(0))
# data = f.read()
# print(f.tell())
# print(data)
# print(f.tell())
# f.close()

## w+ mode
# append and then reading
# f = open("D:/practice_session_topics/f_handling.txt","a+")
# print(f.tell())
# f.write("hi")
# print(f.tell())
# f.seek(0)
# print(f.tell())
# data = f.read()
# print(f.tell())
# print(data)
# print(f.tell())
# f.close()

## copy file content
# f1 = open("D:/practice_session_topics/f_handling.txt","r")
# f2 = open("D:/practice_session_topics/copy.txt","w")
# data = f1.read()
# print(data)
# f2.write(data)
# f1.close()
# f2.close()

## with statement
# with open("D:/practice_session_topics/f_handling.txt","r") as f:
#     data = f.read()
#     print(data)
#     print(f.closed)
# print(f.closed)

#-------------------------------------------------------------------------------------------
# file handling
with open("abc.txt","w") as f:
    dict = {"name":"shubham","middlename":"Dhanraj","surname":"Madavi"}

    f.writelines(dict.values())