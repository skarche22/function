'''l1=[1,2,3,4,5,6,7,8,9,10,11,12]
l2=[]
for x in l1:
    if x>7:
        l2.append(x)

print(l2)'''


l=["m","na","i","so"]
l1=["y","me","s","nu"]
l3=[]
l3.append(l[0]+l1[0])
l3.append(l[1]+l1[1])
l3.append(l[2]+l1[2])
l3.append(l[3]+l1[3])
print(l3)