import numpy as np
# import array
m1=np.array([[1,2,3]
            ,[4,6,7],
             [8,9,0]])
m2=np.array([[2,3,1],[2,4,5],[5,6,7]])
# m3=[[0,0,0],[0,0,0],[0,0,0]]
# m3=m1+m2

# m3=np.add(m1,m2)
# m4=np.dot(m1,m2)
# print(m3)
# print(m4)
print(m1[1:3,1:3])
print(m1[0])