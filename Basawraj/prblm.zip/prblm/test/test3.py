'''def dict(keys,values):
    n=len(keys)
    m=len(values)
    d={}
    if n==m and n>0 :
        d[keys[0]]=values[0]
        dict(keys[1::],values[1::])
    return d
print(dict(zip([1,2],[12,23])))'''
'''def dic(keys,values):
    n=len(keys)
    m=len(keys)
    d={}
    if n==m and n>0 and m>0:
        d[keys[0]]=values[0]
        dic(keys[1::],values[1::])
    return d
tt=dict(zip([1,2],[12,23]))
print(tt)'''

