# l1=[1,2,3,4,5,5]
# l2=[2,3,4,5,5,5]
# z1=list(zip(l1,l2))
# dict1=set(z1)
# print(z1)
# a,b=zip(*z1)
# # # print(l1)
# # # print(l2)
# print(a)
# print(b)
# for i in z1:
#     print(i)
# import random as r
# dict1={"a":1,"B":2}
# l1=list(dict1.values())
# print(r.choice(l1))
t="geeks"
a,b,c,d,e=t
print(a)