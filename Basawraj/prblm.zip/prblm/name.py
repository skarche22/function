fname=input("enter your good namr \t")
lname=input("enter your surname\t")
print(fname+ " "+lname)