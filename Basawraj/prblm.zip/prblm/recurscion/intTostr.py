def swastik(n,base):
    convrt="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    if n < base:
        return convrt[n]
    else:
        return swastik(n//base,base)+ convrt[n % base]
print(swastik(2835,16))
print(swastik(270516,24))
print(swastik(270596,26))
"""def to_string(n,base):
   conver_tString = "0123456789ABCDEF"
   if n < base:
      return conver_tString[n]
   else:
      return to_string(n//base,base) + conver_tString[n % base]

print(to_string(2835,16))
"""
