'''def multfun(list):
    n=len(list)
    if n==1:
        return list[0]
    else:
        return list[0]*multfun(list[1::])
print(multfun([1,2,3]))'''


