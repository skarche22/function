def fun(a,b):
    if b==0:
        return 1
    elif a==0:
        return 0
    elif a==1:
        return 1
    else:
        return a*fun(a,b-1)

print(fun(15,15))