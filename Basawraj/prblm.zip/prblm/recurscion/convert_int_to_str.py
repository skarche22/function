def swastik(n,base):
    convrt="0123456789ABCDEF"
    if n < base:
        return convrt[n]
    else:
        return swastik(n//base,base)+convrt(n%base)


print(swastik(2835,16))
