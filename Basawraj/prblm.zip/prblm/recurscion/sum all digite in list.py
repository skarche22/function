'''def sumfun(list):
    n=len(list)
    if n==1:
        return list[0]
    else:
        return list[0]+sumfun(list[1::])
print(sumfun([10,20,30,40]))'''


def fun(data):
    total=0
    for x in data:
       if type(x) == type([]):
         total= total + fun(x)

       else:
         total =total + x
    return total
z=fun([1,2,[2,3],[4,5,7]])
print(z)

