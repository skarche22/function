# Write a Python program to get the sum of a non-negative integer
'''def fun(n):
    if n == 0:
        return 0
    else:
        return n%10 + fun(n//10)
print(fun(3456))
print(fun(123))'''

# Write a Python program to calculate the harmonic sum of n-1
def fun(n):
    if n<0:
        return 0
    else:
        return 1/n +fun(n-1)
print(fun(-3))
