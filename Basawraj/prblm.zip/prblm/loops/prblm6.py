def test_range(n):
    if n in range(9):
        print( " %s is in the range"%str(n))
    else :
        print("The number is outside the given range.")
test_range(5)