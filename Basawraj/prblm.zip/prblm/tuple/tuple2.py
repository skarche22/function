# t1=(10,11,22,33,44,55)
# t2=t1*3
# print(t2)
t1=(x for x in range(10))
print(tuple(t1))
# print(*t1)

