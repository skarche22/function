dict1 = { "name" : "Nandini", "age" : 18}

# print(dict1.pop('name'))
# del dict1['age']
del dict1['age']
print(dict1)