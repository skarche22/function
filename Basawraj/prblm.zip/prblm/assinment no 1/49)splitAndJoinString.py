def SplitJoin(str):
    splited_string = str.split()
    print(splited_string)
    joined_string = '-'.join(splited_string)
    print(joined_string)
SplitJoin('hello how are you')