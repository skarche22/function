l1 = [("akash", 10), ("gaurav", 12), ("anand", 14),
        ("suraj", 20), ("akhil", 25), ("ashish", 30),(1,'swastik')]
dict1 = dict(l1)
print(dict1)