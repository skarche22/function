def math_operation(a,b):
    sum=0
    sub=0
    mult=1
    div=1
    if a>b:
     print("sum:-",(a+b),"sub:-",(a-b),"mult:-",(a*b),"div:-"(a/b))
math_operation(12,4)
