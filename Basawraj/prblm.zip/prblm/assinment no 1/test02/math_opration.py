def sum_digit(a,b):
    sum=0
    if a!=b:
      sum = a+b
    else:
        sum=b+a
    return sum
def sub_digit(a,b):
    sub=0
    if a>b:
        sub=a-b
    else:
        sub=b-a
    return sub
def fun_mult(a,b):
    mult=a*b
    return mult
def div_digit(a,b):
    div=0
    if a>b:
        div=a/b
    else:
        div=b/a
    return div
print(sum_digit(12,13))
print(sub_digit(13,12))
print(fun_mult(3,4))
print(div_digit(34,2))