# l1=[10,20,30,40,50,60,70,80]
# l2=[]
# for i in range(len(l1)):
#     if i<2:
#         continue
#     else:
#         l2.append(l1[i])
# l2=l2+l1[:2]
# print(l2)

# ---------------------
# left_rotation
l2 = [1,2,3,4,5]
n = 2
for i in range(n):
    temp = l2[0]
    for j in range(len(l2)-1):
        l2[j] = l2[j+1]
    l2[len(l2)-1]=temp
print(l2)
# ---------------------
# right_rotation
l3 = [1,2,3,4,5]
n = 2
for i in range(2):
    temp = l3[-1]
    for j in range(len(l3)-1,0,-1):
        l3[j] = l3[j-1]
    l3[0] = temp
print(l3)