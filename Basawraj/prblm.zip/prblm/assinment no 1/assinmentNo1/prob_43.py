#python prog to print even length words in a string

# str1 = input("enter a string")
# l1 = str1.split(",")
# print(l1)
# for word in l1:
#         if len(word)%2==0:
#             print(word)


# str1 = input("enter a string ")
# def even_len(str1):
#     l1 = str1.split()
#     for word in l1:
#         if len(word) % 2 == 0:
#             print(word)
# even_len(str1)