#python prog to print all odd no in range


## using for loop and range
# lower = int(input("enter the number:"))
# upper = int(input("enter the number:"))
# for i in range(lower,upper):
#     if i%2 != 0:
#      print(i)


## using lambda and filter function
# a = list(filter(lambda x : x%2 != 0, range(lower,upper)))
# print(*a)