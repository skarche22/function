dict1={"a":23,"b":34}
dict2={"c":45,"d":35}
dict1.update(dict2)
print(dict1)