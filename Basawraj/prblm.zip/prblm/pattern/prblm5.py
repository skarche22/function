# o/p
# * * * *
# * * *
# * *
# *

n=int(input("enter num\n"))
for i in range(n):
    print(("* ")*(n-i-1))