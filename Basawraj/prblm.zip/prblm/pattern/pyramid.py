def pattern(n):
    # k = 2 * n - 2


    for i in range(0, n):
        for j in range(0, k):
            print(end=" ")
        # k = k - 1
        for j in range(0, i + 1):
            print("*", end=" ")
        print("\r")


pattern(5)
# def fun(a):
#     if a>0:
#         result = a+fun(a-1)
#         print(result)
#     else:
#         result=0
#
#     return result
# fun(6)