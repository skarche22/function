# o/p
# *
# * *
# * * *
# * * * *


n=int(input("enter number\n"))
for i in range(n):  #0,1,2,3
    print(("* ")*(i+1))
    print()