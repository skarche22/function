a="sarwad"
print("below is reverse string",a[::-2  ])
#print("below is forward string",a[::1])