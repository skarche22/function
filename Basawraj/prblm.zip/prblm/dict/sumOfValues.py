dict1={"a":2,"b":3,"c":10}
sum=0
for x in dict1:
    sum=sum+dict1[x]
print(sum)