dict1={"a":1,"b":2,"c":3,"d":4}
mult=1
for x in dict1.keys():
    mult=mult*dict1[x]
print(mult)