'''def str2(a):
    if len(a)>=3 and a[-3:]=="ing":
        a=a+"ly"
        print(a)
    else:
        a=a+"ing"
        print(a)
str2("swastiking")'''

