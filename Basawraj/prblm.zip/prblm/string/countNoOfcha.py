s1="hello guys how are you"
d1={}
for x in s1:
    if x not in d1:
        d1[x]=1
    else:

        d1[x]=d1[x]+1

print(d1)
print(d1)
print(d1)
print(d1)
print(d1)
print(d1)
